///////////////////////////////////////////////////////////////////
//PACore.hlsl�@(PAToon�f�t�H�p�j
//
//HACore.hlsl(v13), HAHead.hlsl, HgShadowObjHeader.fxh, DirectionalSphere, �@����]�������܂ށB
//�؂�\��͖������Ă��邪�S�̂ɒ��������̂ŗv����
//
//by P.I.P
//
///////////////////////////////////////////////////////////////////


#ifdef MODEL_TOON

//Toon�e�N�X�`���̐F���␳�i���ȊO��Toon�̐F�ɍ��킹��A�����I�ɖ��ʂ������j

texture2D ObjectPTexture <
    string ResourceName = BLENDDIFFUSE2TEXTURE;
>;
sampler2D ObjPTexSampler = sampler_state {
    texture = <ObjectPTexture>;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    MipFilter = NONE;
    AddressU  = CLAMP;
    AddressV = CLAMP;
};

float3 ObjToonTexture : ToonColor;
static float4 ObjToonColor = float4(ObjToonTexture, 1);
static float4 ObjPAToonColor = tex2D(ObjPTexSampler, float2(0,1));
static float4 ToonColorSa = (ObjToonColor - ObjPAToonColor) ;


//static float ObjToonGrey = (1 - (ObjToonColor.r - ObjToonColor.g))
//static float KKK = float(1.0);
//static float4 ObjToonColor = tex2D(ObjToonSampler, float2(0,1));

#endif


////////////////////////////////////////////////////////
////////////////////////////////////////////////////////


//�F���̂��߂̃R���g���[���[�ݒ�

float3 BlendDiffuseTextureRgbAddC : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�e RGB"; >;
float3 BlendDiffuseTextureHsvAddC : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�e HSV"; >;

float3 EdgeColorM : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�G�b�W RGB"; >;


float3 BlendDiffuseTextureRgbAddM : CONTROLOBJECT < string name = "(self)"; string item = "�e RGB"; >;
float3 BlendDiffuseTextureHsvAddM : CONTROLOBJECT < string name = "(self)"; string item = "�e HSV"; >;

float3 EdgeColorC : CONTROLOBJECT < string name = "(self)"; string item = "�G�b�W RGB"; >;


static float3 BlendDiffuseTextureRgbAdd = BlendDiffuseTextureRgbAddM + BlendDiffuseTextureRgbAddC;
static float3 BlendDiffuseTextureHsvAdd = BlendDiffuseTextureHsvAddM + BlendDiffuseTextureHsvAddC;


static float3 EdgeColorController = (EdgeColorM + EdgeColorC)/10;


float3 BlendDiffuseMaterialTextureRgbAddC : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�� RGB"; >;
float3 BlendDiffuseMaterialTextureHsvAddC : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�� HSV"; >;

float3 BlendDiffuseMaterialTextureRgbAddM : CONTROLOBJECT < string name = "(self)"; string item = "�� RGB"; >;
float3 BlendDiffuseMaterialTextureHsvAddM : CONTROLOBJECT < string name = "(self)"; string item = "�� HSV"; >;

static float3 BlendDiffuseMaterialTextureRgbAdd = BlendDiffuseMaterialTextureRgbAddM + BlendDiffuseMaterialTextureRgbAddC;
static float3 BlendDiffuseMaterialTextureHsvAdd = BlendDiffuseMaterialTextureHsvAddM + BlendDiffuseMaterialTextureHsvAddC;


float EdgeThick1C : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�G�b�W��"; >;
float EdgeThick2C : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�G�b�W��"; >;
float EdgeAlphaC : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�G�b�W����"; >;

float EdgeThick1M : CONTROLOBJECT < string name = "(self)"; string item = "�G�b�W��"; >;
float EdgeThick2M : CONTROLOBJECT < string name = "(self)"; string item = "�G�b�W��"; >;
float EdgeAlphaM : CONTROLOBJECT < string name = "(self)"; string item = "�G�b�W����"; >;

static float EdgeThickness = (1.0f - (EdgeThick1C+EdgeThick1M)) * (2.0 * (EdgeThick2C+EdgeThick2M) + 1.0f);
static float EdgeAlpha = (1-EdgeAlphaC) * (1-EdgeAlphaM);


//�@����]�̂��߂̃R���g���[���[�ݒ�

float4x4 BoneMatrixAA : CONTROLOBJECT < string name = "(self)"; string item = "�V�F�[�_�["; >;
float4x4 BoneMatrixBA : CONTROLOBJECT < string name = "(self)"; string item = "�X�t�B�A"; >;

float4x4 BoneMatrixAB : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�V�F�[�_�["; >;
float4x4 BoneMatrixBB : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�X�t�B�A"; >;

static float4x4 BoneMatrixA = mul(BoneMatrixAA, BoneMatrixAB);
static float4x4 BoneMatrixB = mul(BoneMatrixBA, BoneMatrixBB);

//�n�ʉe�F�̂��߂̃R���g���[���[�ݒ�
float4 GroundShadowColorA : CONTROLOBJECT < string name = "(self)"; string item = "�n�ʉe RGB"; >;
float4 GroundShadowColorB : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�n�ʉe RGB"; >;

float GroundShadowAlphaM : CONTROLOBJECT < string name = "(self)"; string item = "�n�ʉe����"; >;
float GroundShadowAlphaC : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�n�ʉe����"; >;
static float GroundShadowAlpha = (1-GroundShadowAlphaM) * (1-GroundShadowAlphaC);



////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// HAHead.hlsl�@ �������� ��
////////////////////////////////////////////////////////////////////////////////


#define DEFINE_TEXTURE_SAMPLER(textureName, samplerName, resourceName, uMode, vMode) \
	texture2D textureName < string ResourceName = resourceName; >; \
	sampler samplerName = sampler_state \
	{ \
		Texture = <textureName>; \
		Filter = Anisotropic; \
		AddressU = uMode; \
		AddressV = vMode; \
		MaxAnisotropy = 16; \
	};

static float NanAsZero(float value)
{
	return isnan(value) ? 0 : value;
}

static float3 GetHsvFromRgb(float3 rgb)
{
	float maxValue = max(max(rgb.r, rgb.g), rgb.b);
	float minValue = min(min(rgb.r, rgb.g), rgb.b);
	float delta = maxValue - minValue;
	float3 hsv = float3(0, 0, maxValue);

	if (delta != 0)
	{
		hsv.y = delta / maxValue;

		if (maxValue <= rgb.r)
			hsv.x = (rgb.g - rgb.b) / delta;
		else if (maxValue <= rgb.g)
			hsv.x = 2 + (rgb.b - rgb.r) / delta;
		else if (maxValue <= rgb.b)
			hsv.x = 4 + (rgb.r - rgb.g) / delta;

		hsv.x /= 6;
	}
	
	return hsv;
}

static float3 GetRgbFromHsv(float3 hsv)
{
	if (hsv.y == 0)
		return float3(hsv.z, hsv.z, hsv.z);
	else
	{
		if (hsv.x < 0)
			hsv.x += 1;
	
		hsv.yz = saturate(hsv.yz);

		float c = hsv.z * hsv.y;
		float x = c * (1 - abs(hsv.x * 6 % 2 - 1));
		float i = floor(hsv.x * 6) % 6;
		float m = hsv.z - c;

		c += m;
		x += m;

		if (i < 1)
			return float3(c, x, m);
		else if (i < 2)
			return float3(x, c, m);
		else if (i < 3)
			return float3(m, c, x);
		else if (i < 4)
			return float3(m, x, c);
		else if (i < 5)
			return float3(x, m, c);
		else
			return float3(c, m, x);
	}
}

struct BlendParameters
{
	float LightNormal;
	float ExtendedLightNormal;
	float ViewNormal;
	float HalfVectorNormal;
	float SpecularValue;
	float2 TextureCoordinate;
	float2 ScreenCoordinate;
	float3 ToonValue;
};

////////////////////////////////////////////////////////////////////////////////
// HAHead.hlsl�@ �����܂� ��
////////////////////////////////////////////////////////////////////////////////


#ifdef BLENDDIFFUSE0TEXTURE
DEFINE_TEXTURE_SAMPLER(BlendDiffuse0Texture, BlendDiffuse0TextureSampler, BLENDDIFFUSE0TEXTURE, Clamp, Clamp)
#endif
#ifdef BLENDDIFFUSE1TEXTURE
DEFINE_TEXTURE_SAMPLER(BlendDiffuse1Texture, BlendDiffuse1TextureSampler, BLENDDIFFUSE1TEXTURE, Clamp, Clamp)
#endif
#ifdef BLENDDIFFUSE2TEXTURE
DEFINE_TEXTURE_SAMPLER(BlendDiffuse2Texture, BlendDiffuse2TextureSampler, BLENDDIFFUSE2TEXTURE, Clamp, Clamp)
#endif
#ifdef BLENDDIFFUSE3TEXTURE
DEFINE_TEXTURE_SAMPLER(BlendDiffuse3Texture, BlendDiffuse3TextureSampler, BLENDDIFFUSE3TEXTURE, Clamp, Clamp)
#endif
#ifdef BLENDDIFFUSESHADOWTEXTURE
DEFINE_TEXTURE_SAMPLER(BlendDiffuseShadowTexture, BlendDiffuseShadowTextureSampler, BLENDDIFFUSESHADOWTEXTURE, Clamp, Clamp)
#endif
#ifdef BLENDSPECULAR0TEXTURE
DEFINE_TEXTURE_SAMPLER(BlendSpecular0Texture, BlendSpecular0TextureSampler, BLENDSPECULAR0TEXTURE, Clamp, Clamp)
#endif
#ifdef BLENDADDSPHERE1TEXTURE
DEFINE_TEXTURE_SAMPLER(BlendAddSphere1Texture, BlendAddSphere1TextureSampler, BLENDADDSPHERE1TEXTURE, Clamp, Clamp)
#endif

#ifdef BLENDDIFFUSEMATERIALTEXTURE
DEFINE_TEXTURE_SAMPLER(BlendDiffuseMaterialTexture, BlendDiffuseMaterialTextureSampler, BLENDDIFFUSEMATERIALTEXTURE, Clamp, Clamp)
#endif




float EdgeWidthRate
<
	string UIName = "�G�b�W��";
	string UIWidget = "Numeric";
	float UIMin = 0;
	float UIMax = 2;
> = 1.0;

float NormalMapResolution
<
string UIName = "�@���}�b�v�𑜓x";
string UIWidget = "Numeric";
float UIMin = 0;
float UIMax = 10;
> = 1;

float3 BlendDiffuse0(float3 target, BlendParameters parameters)
{
	#ifdef BLENDDIFFUSE0TEXTURE
	float3 targetHsv = GetHsvFromRgb(target);
	float4 value = tex2D(BlendDiffuse0TextureSampler, float2(parameters.LightNormal, targetHsv.x));
	
	value.rgb = GetHsvFromRgb(value.rgb);
	targetHsv.x = lerp(targetHsv.x, value.r, value.a);
	target = GetRgbFromHsv(targetHsv);
	#endif
	
	return target;
}

float3 BlendDiffuse1(float3 target, BlendParameters parameters)
{
	#ifdef BLENDDIFFUSE1TEXTURE
	float3 targetHsv = GetHsvFromRgb(target);
	float4 value = tex2D(BlendDiffuse1TextureSampler, float2(parameters.LightNormal, targetHsv.y));
	
	target.r = lerp(target.r, target.r * value.r, value.a);
	target.g = lerp(target.g, target.g * value.g, value.a);
	target.b = lerp(target.b, target.b * value.b, value.a);
	#endif
	
	return target;
}

float3 BlendDiffuse2(float3 target, BlendParameters parameters)
{
	#ifdef BLENDDIFFUSE2TEXTURE
	float4 value = tex2D(BlendDiffuse2TextureSampler, float2(parameters.LightNormal, parameters.ViewNormal));
	
	target.r = lerp(target.r, target.r * value.r, value.a);
	target.g = lerp(target.g, target.g * value.g, value.a);
	target.b = lerp(target.b, target.b * value.b, value.a);
	#endif
	
	return target;
}

float3 BlendDiffuse3(float3 target, BlendParameters parameters)
{
	#ifdef BLENDDIFFUSE3TEXTURE
	float4 value = tex2D(BlendDiffuse3TextureSampler, float2(parameters.LightNormal, parameters.ViewNormal));
	
	target.r += value.r * value.a;
	target.g += value.g * value.a;
	target.b += value.b * value.a;
	#endif
	
	return target;
}

float3 BlendDiffuseShadow(float3 target, BlendParameters parameters)
{
	#ifdef BLENDDIFFUSESHADOWTEXTURE
	float4 value = tex2D(BlendDiffuseShadowTextureSampler, float2(parameters.LightNormal, parameters.ViewNormal));
	
          #ifdef MODEL_TOON
	  static float3 BlendDiffuseTextureRgbAdd1 = BlendDiffuseTextureRgbAdd + ToonColorSa * 10 ;
          #else
          static float3 BlendDiffuseTextureRgbAdd1 = BlendDiffuseTextureRgbAdd;
          #endif

		
	if (BlendDiffuseTextureRgbAdd1.r != 0 ||
		BlendDiffuseTextureRgbAdd1.g != 0 ||
		BlendDiffuseTextureRgbAdd1.b != 0)
		target += BlendDiffuseTextureRgbAdd1 / 10 * value.rgb * value.a;
	
	if (BlendDiffuseTextureHsvAdd.r != 0 ||
		BlendDiffuseTextureHsvAdd.g != 0 ||
		BlendDiffuseTextureHsvAdd.b != 0)
		target = lerp(target, GetRgbFromHsv(GetHsvFromRgb(target) + BlendDiffuseTextureHsvAdd / 10), value.r * value.a);
	


	#endif
	
	return target;
}

float3 BlendDiffuseMaterial(float3 target, BlendParameters parameters)
{
	#ifdef BLENDDIFFUSEMATERIALTEXTURE
	float4 value = tex2D(BlendDiffuseMaterialTextureSampler, float2(parameters.LightNormal, parameters.ViewNormal));
	
		
	if (BlendDiffuseMaterialTextureRgbAdd.r != 0 ||
		BlendDiffuseMaterialTextureRgbAdd.g != 0 ||
		BlendDiffuseMaterialTextureRgbAdd.b != 0)
		target += BlendDiffuseMaterialTextureRgbAdd / 10 * value.rgb * value.a;
		
	if (BlendDiffuseMaterialTextureHsvAdd.r != 0 ||
		BlendDiffuseMaterialTextureHsvAdd.g != 0 ||
		BlendDiffuseMaterialTextureHsvAdd.b != 0)
		target = lerp(target, GetRgbFromHsv(GetHsvFromRgb(target) + BlendDiffuseMaterialTextureHsvAdd / 10), value.r * value.a);
	
	#endif
	
	return target;
}



float3 BlendDiffuse(float3 color, BlendParameters parameters)
{
	color = BlendDiffuse0(color, parameters);
	color = BlendDiffuse1(color, parameters);
	color = BlendDiffuse2(color, parameters);
	color = BlendDiffuse3(color, parameters);
	color = BlendDiffuseShadow(color, parameters);
    color = BlendDiffuseMaterial(color, parameters);

	return color;
}


float3 BlendSpecular0(float3 target, BlendParameters parameters)
{
	#ifdef BLENDSPECULAR0TEXTURE
	float4 value = tex2D(BlendSpecular0TextureSampler, float2(parameters.SpecularValue, parameters.ViewNormal));
	
	target.r = lerp(target.r, target.r * value.r, value.a);
	target.g = lerp(target.g, target.g * value.g, value.a);
	target.b = lerp(target.b, target.b * value.b, value.a);
	#endif
	
	return target;
}

float3 BlendSpecular1(float3 target, BlendParameters parameters)
{
	#ifdef BLENDSPECULAR1TEXTURE
	float4 value = float4(0, 0, 0, 1);
	
	target.r = lerp(target.r, target.r * value.r, value.a);
	target.g = lerp(target.g, target.g * value.g, value.a);
	target.b = lerp(target.b, target.b * value.b, value.a);
	#endif
	
	return target;
}

float3 BlendSpecular(float3 color, BlendParameters parameters)
{
	color = BlendSpecular0(color, parameters);
	color = BlendSpecular1(color, parameters);

	return color;
}

float3 BlendAddSphere0(float3 target, BlendParameters parameters)
{
	#ifdef BLENDADDSPHERE0TEXTURE
	float4 value = float4(parameters.ViewNormal, parameters.ViewNormal, parameters.ViewNormal, 1);
	
	target.r = lerp(target.r, target.r * value.r, value.a);
	target.g = lerp(target.g, target.g * value.g, value.a);
	target.b = lerp(target.b, target.b * value.b, value.a);
	#endif
	
	return target;
}

float3 BlendAddSphere1(float3 target, BlendParameters parameters)
{
	#ifdef BLENDADDSPHERE1TEXTURE
	float3 targetHsv = GetHsvFromRgb(target);
	float4 value = tex2D(BlendAddSphere1TextureSampler, float2(targetHsv.z, 0));
	
	target.r = lerp(target.r, value.r, value.a);
	target.g = lerp(target.g, value.g, value.a);
	target.b = lerp(target.b, value.b, value.a);
	#endif
	
	return target;
}

float3 BlendAddSphere2(float3 target, BlendParameters parameters)
{
	#ifdef BLENDADDSPHERE2TEXTURE
	float4 value = float4(0, 0, 0, 1);
	
	target.r = lerp(target.r, target.r * value.r, value.a);
	target.g = lerp(target.g, target.g * value.g, value.a);
	target.b = lerp(target.b, target.b * value.b, value.a);
	#endif
	
	return target;
}

float3 BlendAddSphere(float3 color, BlendParameters parameters)
{
	color = BlendAddSphere0(color, parameters);
	color = BlendAddSphere1(color, parameters);
	color = BlendAddSphere2(color, parameters);

	return color;
}
////////////////////////////////////////////////////////////
//�G�b�W�F�p�̏�������

float3 BlendEdge0(float3 target, BlendParameters parameters)
{
	#ifdef BLENDEDGE0TEXTURE
	float4 value = float4(0, 0, 0, EdgeAlpha);
	
	target.r = lerp(target.r, target.r * value.r, value.a) + EdgeColorController.x;
	target.g = lerp(target.g, target.g * value.g, value.a) + EdgeColorController.y;
	target.b = lerp(target.b, target.b * value.b, value.a) + EdgeColorController.z;
	#endif
	
	return target;
}

float3 BlendEdge(float3 color, BlendParameters parameters)
{
	color = BlendEdge0(color, parameters);

	return color;
}



////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
//
//  HgShadow_ObjHeader.fxh : HgShadow �I�u�W�F�N�g�e�`��ɕK�v�Ȋ�{�p�����[�^��`�w�b�_�t�@�C��
//  �����̃p�����[�^���V�F�[�_�G�t�F�N�g�t�@�C���� #include ���Ďg�p���܂��B
//  �쐬: �j��P
//
////////////////////////////////////////////////////////////////////////////////////////////////

//HgShadow�t���O�̔���

#ifdef USE_HGSHADOW

// �p�����[�^�錾

// ����p�����[�^
#define HgShadow_CTRLFILENAME  "HgShadow.x"
bool HgShadow_Valid  : CONTROLOBJECT < string name = HgShadow_CTRLFILENAME; >;

float HgShadow_DensityUp   : CONTROLOBJECT < string name = "(self)"; string item = "ShadowDen+"; >;
float HgShadow_DensityDown : CONTROLOBJECT < string name = "(self)"; string item = "ShadowDen-"; >;

#ifndef MIKUMIKUMOVING

float HgShadow_AcsRx : CONTROLOBJECT < string name = HgShadow_CTRLFILENAME; string item = "Rx"; >;
float HgShadow_ObjTr : CONTROLOBJECT < string name = "(self)"; string item = "Tr"; >;
static float HgShadow_Density = max((degrees(HgShadow_AcsRx) + 5.0f*HgShadow_DensityUp + 1.0f)*(1.0f - HgShadow_DensityDown), 0.0f);

#else

shared float HgShadow_MMM_Density;
static float HgShadow_Density = max((HgShadow_MMM_Density + 5.0f*HgShadow_DensityUp)*(1.0f - HgShadow_DensityDown), 0.0f);

#endif


// �e�����`�挋�ʂ��L�^���邽�߂̃����_�[�^�[�Q�b�g
shared texture2D HgShadow_ViewportMap2 : RENDERCOLORTARGET;
sampler2D HgShadow_ViewportMapSamp = sampler_state {
    texture = <HgShadow_ViewportMap2>;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    MipFilter = LINEAR;
    AddressU  = CLAMP;
    AddressV  = CLAMP;
};


// �X�N���[���T�C�Y
float2 HgShadow_ViewportSize : VIEWPORTPIXELSIZE;
static float2 HgShadow_ViewportOffset = (float2(0.5,0.5)/HgShadow_ViewportSize);


// �Z���t�V���h�E�̎Օ��������߂�
float HgShadow_GetSelfShadowRate(float4 PPos)
{
    // �X�N���[���̍��W
    float2 texCoord = float2( ( PPos.x/PPos.w + 1.0f ) * 0.5f,
                              1.0f - ( PPos.y/PPos.w + 1.0f ) * 0.5f ) + HgShadow_ViewportOffset;

    // �Օ���
    float comp = 1.0f - tex2Dlod( HgShadow_ViewportMapSamp, float4(texCoord, 0, 0) ).r;

    return (1.0f-(1.0f-comp) * min(HgShadow_Density, 1.0f));
}


struct HgShadow_COLOR {
    float4 Color;        // �I�u�W�F�N�g�F
    float4 ShadowColor;  // �e�F
};


// �e�F�ɔZ�x����������
HgShadow_COLOR HgShadow_GetShadowDensity(float4 Color, float4 ShadowColor, bool useToon, float LightNormal)
{
    HgShadow_COLOR Out;
    Out.Color = Color;
    Out.ShadowColor = ShadowColor;

    if( !useToon || length(Color.rgb-ShadowColor.rgb) > 0.01f ){
        float e = max(HgShadow_Density, 1.0f);
        float a = 1.0f / e;
        float b = 1.0f - smoothstep(3.0f, 6.0f, e);
        float3 color = lerp(ShadowColor.rgb*a, ShadowColor.rgb*b, pow(ShadowColor.rgb, e));
        Out.ShadowColor = float4(saturate(color), ShadowColor.a);
    }
    if( !useToon ){
        float e = lerp( max(HgShadow_Density, 1.0f), 1.0f, smoothstep(0.0f, 0.4f, LightNormal) );
        float a = 1.0f / e;
        float b = 1.0f - smoothstep(3.0f, 6.0f, e);
        float3 color = lerp(Color.rgb*a, Color.rgb*b, pow(Color.rgb, e));
        Out.Color = float4(saturate(color), Color.a);
        #ifndef MIKUMIKUMOVING
        Out.Color.a *= HgShadow_ObjTr;
        Out.ShadowColor.a *= HgShadow_ObjTr;
        #endif
    }

    return Out;
}

#endif

/////////////////////////////////////////////////////////////////////////////////////////////////
//HgShadow_ObjHeader.fxh  �������܂�
/////////////////////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
//
//  LocalShadow_Header1.fxh : LocalShadow(���f���g�ݍ��ݔ�) �쐬: �j��P
//
//  ���p�����[�^�[�ݒ�͂��̃t�@�C���̖`���Ɉړ����Ă��܂��B by P.I.P
//
////////////////////////////////////////////////////////////////////////////////////////////////

//LocalShadow�t���O�̔���

#ifdef USE_LOCALSHADOW

// �p�����[�^��`

//�R���g���[���[�p

float3   LocalShadow_BonePosC     : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�Z���t�e"; >;
float4x4 LocalShadow_BoneMatrixC  : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�Z���t�e"; >;

float    LocalShadow_MorphLtSyncC : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "Lt�A�e�A��"; >;

float LocalShadow_MorphSize1C    : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�͈͏k��"; >;
float LocalShadow_MorphSize2C    : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�͈͊g��"; >;
float LocalShadow_MorphSize2XC   : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "X�͈͊g��"; >;
float LocalShadow_MorphSize2YC   : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "Y�͈͊g��"; >;


float LocalShadow_MorphDist1C    : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "������"; >;
float LocalShadow_MorphDist2C    : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "������"; >;

float LocalShadow_MorphLtCtrlC   : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "Lt�e�Z����"; >;
//float LocalShadow_ObjTrC : CONTROLOBJECT < string name = "(self)"; string item = "Tr"; >;




// ���f�����ߍ��݃p�����[�^
float3   LocalShadow_BonePosM     : CONTROLOBJECT < string name = "(self)"; string item = "�Z���t�e"; >;
float4x4 LocalShadow_BoneMatrixM  : CONTROLOBJECT < string name = "(self)"; string item = "�Z���t�e"; >;
float    LocalShadow_MorphLtSyncM : CONTROLOBJECT < string name = "(self)"; string item = "Lt�A�e�A��"; >;

float LocalShadow_MorphSize1M    : CONTROLOBJECT < string name = "(self)"; string item = "�͈͏k��"; >;
float LocalShadow_MorphSize2M    : CONTROLOBJECT < string name = "(self)"; string item = "�͈͊g��"; >;
float LocalShadow_MorphSize2XM   : CONTROLOBJECT < string name = "(self)"; string item = "X�͈͊g��"; >;
float LocalShadow_MorphSize2YM   : CONTROLOBJECT < string name = "(self)"; string item = "Y�͈͊g��"; >;


float LocalShadow_MorphDist1M    : CONTROLOBJECT < string name = "(self)"; string item = "������"; >;
float LocalShadow_MorphDist2M    : CONTROLOBJECT < string name = "(self)"; string item = "������"; >;

float LocalShadow_MorphLtCtrlM   : CONTROLOBJECT < string name = "(self)"; string item = "Lt�e�Z����"; >;
//float LocalShadow_ObjTrM : CONTROLOBJECT < string name = "(self)"; string item = "Tr"; >;

//�p�����[�^�̍��Z

static float3   LocalShadow_BonePos    = LocalShadow_BonePosC + LocalShadow_BonePosM;
static float4x4 LocalShadow_BoneMatrix = mul(LocalShadow_BoneMatrixC, LocalShadow_BoneMatrixM);

static float    LocalShadow_MorphLtSync = LocalShadow_MorphLtSyncC + LocalShadow_MorphLtSyncM;

static float LocalShadow_MorphSize1  = LocalShadow_MorphSize1C + LocalShadow_MorphSize1M;
static float LocalShadow_MorphSize2  = LocalShadow_MorphSize2C + LocalShadow_MorphSize2M;
static float LocalShadow_MorphSize2X = LocalShadow_MorphSize2XC + LocalShadow_MorphSize2XM;
static float LocalShadow_MorphSize2Y = LocalShadow_MorphSize2YC + LocalShadow_MorphSize2YM;


static float LocalShadow_MorphDist1  = LocalShadow_MorphDist1C + LocalShadow_MorphDist1M;
static float LocalShadow_MorphDist2  = LocalShadow_MorphDist2C +  LocalShadow_MorphDist2M;

static float LocalShadow_MorphLtCtrl = LocalShadow_MorphLtCtrlC + LocalShadow_MorphLtCtrlM;
static float LocalShadow_ObjTr : CONTROLOBJECT < string name = "(self)"; string item = "Tr"; >;

// �N�H�[�^�j�I���̐ώZ
float4 LocalShadow_MulQuat(float4 q1, float4 q2)
{
   return float4(cross(q1.xyz, q2.xyz)+q1.xyz*q2.w+q2.xyz*q1.w, q1.w*q2.w-dot(q1.xyz, q2.xyz));
}

// �N�H�[�^�j�I���̉�]
float3 LocalShadow_RotQuat(float3 v1, float3 v2, float3 pos)
{
   float3 s = cross(v2, v1);
   if( !any(s) ) s = float3(1,0,0);
   float3 v = normalize( s );
   float rot = acos( dot(v1, v2) );
   float sinHD = sin(0.5f * rot);
   float cosHD = cos(0.5f * rot);
   float4 q1 = float4(v*sinHD, cosHD);
   float4 q2 = float4(-v*sinHD, cosHD);
   float4 q = LocalShadow_MulQuat( LocalShadow_MulQuat(q2, float4(pos, 0.0f)), q1);

   return q.xyz;
}

// ���C�g����(�G�t�F�N�g�ݒ����)
float3 LocalShadow_LtDirection : DIRECTION < string Object = "Light"; >;
static float3 LocalShadow_LtCtrlDir = LocalShadow_RotQuat(float3(0,0.0001,1), normalize(LocalShadow_BoneMatrix._31_32_33), normalize(LS_InitDirection));
static float  LocalShadow_MorphLtSync1 = lerp(LS_LightSyncShade, 1.0f, LocalShadow_MorphLtSync);
static float  LocalShadow_MorphLtSync2 = lerp(LS_LightSyncShadow, 1.0f, LocalShadow_MorphLtSync);
static float3 LocalShadow_LightDirection = normalize(lerp(LocalShadow_LtCtrlDir, LocalShadow_LtDirection, LocalShadow_MorphLtSync2));

// ���C�g����
static float LocalShadow_Distance = 15.0f - 14.0f*LocalShadow_MorphDist1 + 85.0f*LocalShadow_MorphDist2;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ���W�ϊ��s��

// ���C�g�����̃r���[�ϊ��s��
float4x4 LocalShadow_LightViewMatrix()
{
   // z�������x�N�g��
   float3 viewZ = LocalShadow_LightDirection;

   // x�������x�N�g��
   float3 viewX = cross( LocalShadow_BoneMatrix._21_22_23, LocalShadow_LightDirection ); 

   // x�������x�N�g���̐��K��(LookDir��LookUpDir�̕�������v����ꍇ�͓��ْl�ƂȂ�)
   if( !any(viewX) ) viewX = LocalShadow_BoneMatrix._11_21_31;
   viewX = normalize(viewX);

   // y�������x�N�g��
   float3 viewY = cross( viewZ, viewX );  // ���ɐ����Ȃ̂ł���Ő��K��

   // �r���[���W�ϊ��̉�]�s��
   float3x3 ltViewRot = float3x3( viewX.x, viewY.x, viewZ.x,
                                  viewX.y, viewY.y, viewZ.y,
                                  viewX.z, viewY.z, viewZ.z );

   // ���̌����ʒu
   float3 ltViewPos = LocalShadow_BonePos - LocalShadow_LightDirection * LS_ShadowMapDepthLength;

   // �r���[�ϊ��s��
   return float4x4( ltViewRot[0],  0,
                    ltViewRot[1],  0,
                    ltViewRot[2],  0,
                   -mul( ltViewPos, ltViewRot ), 1 );
}


// ���C�g�����̎ˉe�ϊ��s��
float4x4 LocalShadow_LightProjMatrix()
{
//   float s = 2.0f / LS_ShadowMapAreaSize;
//   float d = 0.5f / LS_ShadowMapDepthLength;
//
//   return float4x4( s, 0, 0, 0,
//                    0, s, 0, 0,
//                    0, 0, d, 0,
//                    0, 0, 0, 1 );

   float sx = 1.0f / (5.0f - 4.0f*LocalShadow_MorphSize1 + 20.0f*LocalShadow_MorphSize2 + 95.0f*LocalShadow_MorphSize2X);
   float sy = 1.0f / (5.0f - 4.0f*LocalShadow_MorphSize1 + 20.0f*LocalShadow_MorphSize2 + 95.0f*LocalShadow_MorphSize2Y);
   float d = 0.5f / LocalShadow_Distance;

   return float4x4( sx, 0,  0, 0,
                    0,  sy, 0, 0,
                    0,  0,  d, 0,
                    0,  0,  0, 1 );

}


float4x4 LocalShadow_WorldMatrix : WORLD;

static float4x4 LocalShadow_LightViewProjMatrix = mul( LocalShadow_LightViewMatrix(), LocalShadow_LightProjMatrix() );
static float4x4 LocalShadow_LightWorldViewProjMatrix = mul( LocalShadow_WorldMatrix, LocalShadow_LightViewProjMatrix );


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef LOCALSHADOWMAPDRAW

// �t�F�C�X�ގ�����
//float LocalShadow_SpecularPower : SPECULARPOWER < string Object = "Geometry"; >;
//static bool LocalShadow_Valid = (abs(frac(LocalShadow_SpecularPower*10.0f) - LS_ExecKey) < 0.001f);

float LocalShadow_Valid = 1;

// ���C�g�����̏C��
float3 LocalShadow_GetLightDirection(float3 ltDir)
{
    if( 1 ){
        ltDir = normalize( lerp(LocalShadow_LtCtrlDir, ltDir, LocalShadow_MorphLtSync1) );
    }
    return ltDir;
}


////////////////////////////////////////////////////////////////////////////////////////////////

// �V���h�E�}�b�v�֘A�̏���

// �V���h�E�}�b�v�o�b�t�@�T�C�Y
#define SMAPSIZE_WIDTH   LS_ShadowMapBuffSize
#define SMAPSIZE_HEIGHT  LS_ShadowMapBuffSize

#if LS_UseSoftShadow==1
    #define TEX_FORMAT  "D3DFMT_G32R32F"
    #define TEX_MIPLEVELS  0
#else
    #define TEX_FORMAT  "D3DFMT_R32F"
    #define TEX_MIPLEVELS  1
#endif

// �I�t�X�N���[���V���h�E�}�b�v�o�b�t�@
texture LS_ShadowMap : OFFSCREENRENDERTARGET <
    string Description = "PAToon+�̃V���h�E�}�b�v�iLocal_ShadowMap.fxsub�����蓖�Ă邩�A�`�F�b�N���O���j";
    int Width  = SMAPSIZE_WIDTH;
    int Height = SMAPSIZE_HEIGHT;
    float4 ClearColor = { 1, 1, 1, 1 };
    float ClearDepth = 1.0;
    string Format = TEX_FORMAT;
    bool AntiAlias = false;
    int Miplevels = TEX_MIPLEVELS;
    string DefaultEffect = 
        "self = LocalShadow_ShadowMap.fxsub;"
        "* = LocalShadow_ShadowMap.fxsub;";
>;
sampler LocalShadow_ShadowMapSamp = sampler_state {
    texture = <LS_ShadowMap>;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    MipFilter = LINEAR;
    AddressU  = CLAMP;
    AddressV = CLAMP;
};



// �e�Z�x
float LocalShadow_MorphSdDens1M : CONTROLOBJECT < string name = "(self)"; string item = "�e����"; >;
float LocalShadow_MorphSdDens2M : CONTROLOBJECT < string name = "(self)"; string item = "�e�Z��"; >;

float LocalShadow_MorphSdDens1C : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�e����"; >;
float LocalShadow_MorphSdDens2C : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�e�Z��"; >;

static float LocalShadow_MorphSdDens1 = LocalShadow_MorphSdDens1C + LocalShadow_MorphSdDens1M;
static float LocalShadow_MorphSdDens2 = LocalShadow_MorphSdDens2C + LocalShadow_MorphSdDens2M;

static float LocalShadow_MorphLtSync3 = lerp(LS_LightSyncDensity, 1.0f, LocalShadow_MorphLtSync);
static float LocalShadow_LtCtrlDens = smoothstep(-1.5f+1.5f*LocalShadow_MorphLtSync3, LocalShadow_MorphLtSync3, dot(LocalShadow_LightDirection, LocalShadow_LtDirection));
static float LocalShadow_Density1 = (1.0f - LocalShadow_MorphSdDens1) * LocalShadow_LtCtrlDens;
static float LocalShadow_Density2 = 1.0f + 5.0f * LocalShadow_MorphSdDens2;


#if LS_UseSoftShadow==1
// VSM�V���h�E�}�b�v�֘A�̏���

    // �ڂ������x
    float LocalShadow_MorphSdBulrM : CONTROLOBJECT < string name = "(self)"; string item = "�e�ڂ���"; >;
    float LocalShadow_MorphSdBulrC : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�e�ڂ���"; >;
    static float LocalShadow_MorphSdBulr = LocalShadow_MorphSdBulrC + LocalShadow_MorphSdBulrM;

    static float LocalShadow_ShadowBulrPower = lerp(LS_InitBlurPower, 1.0f, LocalShadow_MorphSdBulr) * 5.0f;

    // �V���h�E�}�b�v�̎��ӃT���v�����O��
    #define BASESMAP_COUNT  4

    // �V���h�E�}�b�v�o�b�t�@�T�C�Y
    #define SMAPSIZE_WIDTH   LS_ShadowMapBuffSize
    #define SMAPSIZE_HEIGHT  LS_ShadowMapBuffSize

    // �V���h�E�}�b�v�̃T���v�����O�Ԋu
    static float2 LocalShadow_SMapSampStep = float2(LocalShadow_ShadowBulrPower/SMAPSIZE_WIDTH, LocalShadow_ShadowBulrPower/SMAPSIZE_HEIGHT);

    // �V���h�E�}�b�v�̎��ӃT���v�����O1
    float2 LocalShadow_GetZPlotSampleBase1(float2 Tex, float smpScale)
    {
        float2 smpStep = LocalShadow_SMapSampStep * smpScale;
        float mipLv = log2( max(SMAPSIZE_WIDTH*smpStep.x, 1.0f) );
        float2 zplot = tex2Dlod(LocalShadow_ShadowMapSamp, float4(Tex, 0, mipLv)).xy * 2.0f;
        zplot += tex2Dlod(LocalShadow_ShadowMapSamp, float4(Tex+smpStep*float2(-1,-1), 0, mipLv)).xy;
        zplot += tex2Dlod(LocalShadow_ShadowMapSamp, float4(Tex+smpStep*float2( 1,-1), 0, mipLv)).xy;
        zplot += tex2Dlod(LocalShadow_ShadowMapSamp, float4(Tex+smpStep*float2(-1, 1), 0, mipLv)).xy;
        zplot += tex2Dlod(LocalShadow_ShadowMapSamp, float4(Tex+smpStep*float2( 1, 1), 0, mipLv)).xy;
        return (zplot / 6.0f);
    }

    // �V���h�E�}�b�v�̎��ӃT���v�����O2
    float2 LocalShadow_GetZPlotSampleBase2(float2 Tex, float smpScale)
    {
        float2 smpStep = LocalShadow_SMapSampStep * smpScale;
        float mipLv = log2( max(SMAPSIZE_WIDTH*smpStep.x, 1.0f) );
        float2 zplot = tex2Dlod(LocalShadow_ShadowMapSamp, float4(Tex, 0, mipLv)).xy * 2.0f;
        zplot += tex2Dlod(LocalShadow_ShadowMapSamp, float4(Tex+smpStep*float2(-1, 0), 0, mipLv)).xy;
        zplot += tex2Dlod(LocalShadow_ShadowMapSamp, float4(Tex+smpStep*float2( 1, 0), 0, mipLv)).xy;
        zplot += tex2Dlod(LocalShadow_ShadowMapSamp, float4(Tex+smpStep*float2( 0,-1), 0, mipLv)).xy;
        zplot += tex2Dlod(LocalShadow_ShadowMapSamp, float4(Tex+smpStep*float2( 0, 1), 0, mipLv)).xy;
        return (zplot / 6.0f);
    }

    // �Z���t�V���h�E�̎Օ��m�������߂�
    float LocalShadow_GetSelfShadowRate(float2 SMapTex, float z)
    {
        // �V���h�E�}�b�v���Z�v���b�g�̓��v����(zplot.x:����, zplot.y:2�敽��)
        float2 zplot = float2(0,0);
        float rate = 1.0f;
        float sumRate = 0.0f;
        [unroll]
        for(int i=0; i<BASESMAP_COUNT; i+=2) {
            rate *= 0.5f; sumRate += rate;
            zplot += LocalShadow_GetZPlotSampleBase1(SMapTex, float(i+1)) * rate;
            rate *= 0.5f; sumRate += rate;
            zplot += LocalShadow_GetZPlotSampleBase2(SMapTex, float(i+2)) * rate;
        }
        zplot /= sumRate;

        // �e������(VSM:Variance Shadow Maps�@)
        float variance = max( zplot.y - zplot.x * zplot.x, 0.05f/LS_ShadowMapDepthLength );
        float comp = variance / (variance + max(z - zplot.x, 0.0f));

        comp = smoothstep(0.1f/max(LocalShadow_ShadowBulrPower, 1.0f), 1.0f, comp);
        return (1.0f-(1.0f-comp)*LocalShadow_Density1);
    }

#else
// �\�t�g�V���h�E���g��Ȃ��ꍇ

    #define LocalShadow_SKII1  (200.0f*LS_ShadowMapDepthLength)

    // �Z���t�V���h�E�̎Օ��m�������߂�
    float LocalShadow_GetSelfShadowRate(float2 SMapTex, float z)
    {
        float comp;
        float dist = max( z - tex2D(LocalShadow_ShadowMapSamp, SMapTex).r, 0.0f );
        comp = 1.0f - saturate( dist * LocalShadow_SKII1 - 7.0f);

        return (1.0f-(1.0f-comp)*LocalShadow_Density1);
    }

#endif


////////////////////////////////////////////////////////////////////////////////////////////////
// �Z�x�ݒ�֘A�̏���

struct  LocalShadow_COLOR {
    float4 Color;        // �I�u�W�F�N�g�F
    float4 ShadowColor;  // �e�F
};

// �e�F�ɔZ�x����������
LocalShadow_COLOR LocalShadow_GetShadowDensity(float4 Color, float4 ShadowColor, bool useToon, float LightNormal)
{
    LocalShadow_COLOR Out;
    Out.Color = Color;

    float e = max(LocalShadow_Density2, 1.0f);
    float a = 1.0f / e;
    float b = 1.0f - smoothstep(3.0f, 6.0f, e);
    float3 color = lerp(ShadowColor.rgb*a, ShadowColor.rgb*b, pow(ShadowColor.rgb, e));
    Out.ShadowColor = float4(saturate(color), ShadowColor.a);

    return Out;
}


#endif

/////////////////////////////////////////////////////////////////////
#endif

///////////////////////////////////////////////////////
//  "LocalShadow_Header.fxh"  �����܂� ��
///////////////////////////////////////////////////////////////////////////////////////////////////






/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
// "DirectionalSphere.h"  �������� ��
/////////////////////////////////////////////////////////////////////////////////////

#ifndef	DEC_LOCAL2DIRSPHERE
#define	DEC_LOCAL2DIRSPHERE( parts, dir )\
float4x4		s_mtxDirectionalSphNode		: CONTROLOBJECT < string name = "(self)"; string item = parts; >;\
float4x4		s_mtxDirectionalSphView		: VIEW;\
float3			s_vSphereDirection			= dir;\
static float3	s_vDirectionalSphU			= normalize( cross( mul( s_vSphereDirection, (float3x3)s_mtxDirectionalSphNode ), s_mtxDirectionalSphView._13_23_33 ) );\
static float3	s_vDirectionalSphV			= normalize( cross( s_mtxDirectionalSphView._13_23_33, s_vDirectionalSphU ) );\
float2			LocalNormalToDirSph( float3 vNormal ) { \
	float2	uv;\
	uv.x	= +dot( s_vDirectionalSphU, vNormal );\
	uv.y	= -dot( s_vDirectionalSphV, vNormal );\
	return	uv * 0.5 - 0.5;\
}
#endif

// LocalNormalToDirSph�֐����g����悤�ɂ��܂�
DEC_LOCAL2DIRSPHERE( "��", float3( 0, 1, 0 ) );
// �X�t�B�A��UV�v�Z�̂Ƃ����LocalNormalToDirSph���Ă�ł܂�

float SphereZCTR    : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�̨��Ǐ]��"; >;
float SphereZModel  : CONTROLOBJECT < string name = "(self)" ; string item = "�̨��Ǐ]��"; >;

static float SphereZ = 1 - ((1 -SphereZCTR) * (1-SphereZModel));


////////////////////////////////////////////////////////
// "DirectionalSphere.h"  �����܂� ��
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  #include "HACore.hlsl" �𓝍�
//�������� ��
//////////////////////////////////////////////////////////////////////////////////////////////////////////////


// HACore rel. 13

float4x4	WorldViewProjMatrix	: WORLDVIEWPROJECTION;
float4x4	WorldMatrix			: WORLD;
float4x4	ViewMatrix			: VIEW;
float4x4	ProjMatrix			: PROJECTION;
float3		CameraPosition		: POSITION		< string Object = "Camera"; >;

float4		MaterialDiffuse		: DIFFUSE		< string Object = "Geometry"; >;
float3		MaterialAmbient		: AMBIENT		< string Object = "Geometry"; >;
float3		MaterialEmmisive	: EMISSIVE		< string Object = "Geometry"; >;
float3		MaterialSpecular	: SPECULAR		< string Object = "Geometry"; >;
float		SpecularPower		: SPECULARPOWER	< string Object = "Geometry"; >;
float3		MaterialToon		: TOONCOLOR;
float4		EdgeColorModel		: EDGECOLOR;

static float4 EdgeColor = EdgeColorModel + float4(EdgeColorController, 0.0);

/////////////////////////////////////////
//PAToon�p�̉���

float4		GroundShadowColorC	: GROUNDSHADOWCOLOR;
static float3 GroundShadowColorS = GroundShadowColorA + GroundShadowColorB + GroundShadowColorC;
static float4 GroundShadowColor = float4(GroundShadowColorS.r, GroundShadowColorS.g, GroundShadowColorS.b, GroundShadowColorC.a * GroundShadowAlpha);

float      AddingSphereCTR   : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "���Z�̨���"; >;
float      AddingSphereModel : CONTROLOBJECT < string name = "(self)"; string item = "���Z�̨���"; >;

float      MultiplySphereCTR   : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "��Z�̨���"; >;
float      MultiplySphereModel : CONTROLOBJECT < string name = "(self)"; string item = "��Z�̨���"; >;

static float AddingSphereP = (AddingSphereCTR + AddingSphereModel) ;
static float MultiplySphereP = (1 - MultiplySphereCTR) * (1 - MultiplySphereModel) ;

/////////////////////////////////////////


float4		AddingTexture		: ADDINGTEXTURE;
float4		MultiplyTexture		: MULTIPLYINGTEXTURE;

#ifdef MIKUMIKUMOVING

float4		AddingSphere		: ADDINGSPHERE;
float4		MultiplySphere		: MULTIPLYINGSPHERE;

#else

float4		AddingSphere		: ADDINGSPHERETEXTURE;
float4		MultiplySphere		: MULTIPLYINGSPHERETEXTURE;


#endif

float2 ViewportSize : VIEWPORTPIXELSIZE;
static float2 ViewportOffset = float2(0.5, 0.5) / ViewportSize;

#ifdef USE_EXCELLENTSHADOW

float X_SHADOWPOWER = 1.0;
float PMD_SHADOWPOWER = 0.2;

shared texture2D ScreenShadowMapProcessed : RENDERCOLORTARGET
<
	float2 ViewPortRatio = { 1.0, 1.0 };
int MipLevels = 1;
string Format = "D3DFMT_R16F";
> ;
sampler2D ScreenShadowMapProcessedSamp = sampler_state
{
	texture = <ScreenShadowMapProcessed>;
	MinFilter = LINEAR;
	MagFilter = LINEAR;
	MipFilter = NONE;
	AddressU = CLAMP;
	AddressV = CLAMP;
};

shared texture2D ExShadowSSAOMapOut : RENDERCOLORTARGET
<
	float2 ViewPortRatio = { 1.0, 1.0 };
int MipLevels = 1;
string Format = "R16F";
> ;

sampler2D ExShadowSSAOMapSamp = sampler_state
{
	texture = <ExShadowSSAOMapOut>;
	MinFilter = LINEAR;
	MagFilter = LINEAR;
	MipFilter = NONE;
	AddressU = CLAMP;
	AddressV = CLAMP;
};

bool Exist_ExcellentShadow : CONTROLOBJECT < string name = "ExcellentShadow.x"; > ;
bool Exist_ExShadowSSAO : CONTROLOBJECT < string name = "ExShadowSSAO.x"; > ;
float ShadowRate : CONTROLOBJECT < string name = "ExcellentShadow.x"; string item = "Tr"; > ;
float3 ES_CameraPos1 : POSITION < string Object = "Camera"; > ;
float es_size0 : CONTROLOBJECT < string name = "ExcellentShadow.x"; string item = "Si"; > ;
float4x4 es_mat1 : CONTROLOBJECT < string name = "ExcellentShadow.x"; > ;

static float3 es_move1 = float3(es_mat1._41, es_mat1._42, es_mat1._43);
static float CameraDistance1 = length(ES_CameraPos1 - es_move1);

#endif

#ifdef MIKUMIKUMOVING

float		EdgeWidth : EDGEWIDTH;

bool		LightEnables[MMM_LightCount]		: LIGHTENABLES;
float4x4	LightWVPMatrices[MMM_LightCount]	: LIGHTWVPMATRICES;
float3		LightDirection[MMM_LightCount]		: LIGHTDIRECTIONS;

float3		LightDiffuses[MMM_LightCount]		: LIGHTDIFFUSECOLORS;
float3		LightAmbients[MMM_LightCount]		: LIGHTAMBIENTCOLORS;
float3		LightSpeculars[MMM_LightCount]		: LIGHTSPECULARCOLORS;

float3		LightPositions[MMM_LightCount]		: LIGHTPOSITIONS;
float		LightZFars[MMM_LightCount]			: LIGHTZFARS;

static float4 DiffuseColor[MMM_LightCount] =
{
	MaterialDiffuse * float4(LightDiffuses[0], 1.0f),
	MaterialDiffuse * float4(LightDiffuses[1], 1.0f),
	MaterialDiffuse * float4(LightDiffuses[2], 1.0f)
};
static float3 AmbientColor[MMM_LightCount] =
{
	saturate(MaterialAmbient * LightAmbients[0] + MaterialEmmisive),
	saturate(MaterialAmbient * LightAmbients[1] + MaterialEmmisive),
	saturate(MaterialAmbient * LightAmbients[2] + MaterialEmmisive)
};
static float3 SpecularColor[MMM_LightCount] =
{
	MaterialSpecular * LightSpeculars[0],
	MaterialSpecular * LightSpeculars[1],
	MaterialSpecular * LightSpeculars[2]
};

#else

#define MMM_LightCount 1

float		EdgeWidth = 1;

float4x4	LightWorldViewProjMatrix			: WORLDVIEWPROJECTION < string Object = "Light"; > ;
float3		LightDirection0						: DIRECTION < string Object = "Light"; > ;
float3		LightDiffuse						: DIFFUSE < string Object = "Light"; > ;
float3		LightAmbient						: AMBIENT < string Object = "Light"; > ;
float3		LightSpecular						: SPECULAR < string Object = "Light"; > ;

static bool		LightEnables[MMM_LightCount] = { true };
static float4x4	LightWVPMatrices[MMM_LightCount] = { LightWorldViewProjMatrix };
static float3	LightDirection[MMM_LightCount] = { LightDirection0 };

static float3	LightDiffuses[MMM_LightCount] = { LightDiffuse };
static float3	LightAmbients[MMM_LightCount] = { LightAmbient };
static float3	LightSpeculars[MMM_LightCount] = { LightSpecular };

static float4 DiffuseColor[MMM_LightCount] =
{
	MaterialDiffuse * float4(LightDiffuses[0], 1.0f)
};
static float3 AmbientColor[MMM_LightCount] =
{
	saturate(MaterialAmbient * LightAmbients[0] + MaterialEmmisive)
};
static float3 SpecularColor[MMM_LightCount] =
{
	MaterialSpecular * LightSpeculars[0]
};

#endif

bool	use_texture;		// �e�N�X�`���g�p
bool	use_spheremap;		// �X�t�B�A�}�b�v�g�p
bool	use_toon;			// �g�D�[���`�悩�ǂ��� (�A�N�Z�T��: false, ���f��: true)
bool	transp;				// �������t���O
bool	spadd;				// �X�t�B�A�}�b�v���Z�����t���O

#ifdef MIKUMIKUMOVING

bool    usetoontexturemap;	// Toon �e�N�X�`�����g�p���邩�ǂ����� (MMM)

#else

bool	parthf;				// �Z���t�V���h�E�t���O (mode1: false, mode2: true)
#define SKII1	1500
#define SKII2	8000
#define Toon	3
sampler DefSampler : register(s0);

#endif

texture ObjectTexture : MATERIALTEXTURE;
sampler ObjTexSampler = sampler_state
{
	Texture = <ObjectTexture>;
	MinFilter = Anisotropic;
	MagFilter = Anisotropic;
	MipFilter = Linear;
	MaxAnisotropy = 16;
};
texture ObjectSphereMap : MATERIALSPHEREMAP;
sampler ObjSphereSampler = sampler_state
{
	Texture = <ObjectSphereMap>;
	MinFilter = Anisotropic;
	MagFilter = Anisotropic;
	MipFilter = Linear;
	MaxAnisotropy = 16;
};

//2.8+�ł͐�Ɏ擾���Ă��悤�ȋC�����邩��s�v�����H
texture ObjectToonTexture : MATERIALTOONTEXTURE;
sampler ObjToonSampler = sampler_state
{
	texture = <ObjectToonTexture>;
	MinFilter = Linear;
	MagFilter = Linear;
	MipFilter = None;
	AddressU = Clamp;
	AddressV = Clamp;
};

///////////////////////////////////////////////////////////////////////////////////////////////

#ifdef USE_NORMALMAP

texture2D NormalMap
<
	string ResourceName = USE_NORMALMAP;
	int MipLevels = 0;
> ;
sampler2D NormalMapSampler = sampler_state
{
	texture = <NormalMap>;
	MINFILTER = Anisotropic;
	MAGFILTER = Anisotropic;
	MIPFILTER = Linear;
	MAXANISOTROPY = 16;
	AddressU = Wrap;
	AddressV = Wrap;
};

float3x3 ComputeTangentFrame(float3 Normal, float3 View, float2 UV)
{
	float3 dp1 = ddx(View);
	float3 dp2 = ddy(View);
	float2 duv1 = ddx(UV);
	float2 duv2 = ddy(UV);
	float3x3 M = float3x3(dp1, dp2, cross(dp1, dp2));
	float2x3 inverseM = float2x3(cross(M[1], M[2]), cross(M[2], M[0]));
	float3 Tangent = mul(float2(duv1.x, duv2.x), inverseM);
	float3 Binormal = mul(float2(duv1.y, duv2.y), inverseM);

	return float3x3(normalize(Tangent), normalize(Binormal), Normal);
}

#endif

///////////////////////////////////////////////////////////////////////////////////////////////

struct VS_OUTPUT
{
	float4 Pos				: POSITION;		// �ˉe�ϊ����W
	float4 ZCalcTex			: TEXCOORD0;	// Z �l
	float2 Tex				: TEXCOORD1;	// �e�N�X�`��
	float3 Normal			: TEXCOORD2;	// �@��
	float3 Eye				: TEXCOORD3;	// �J�����Ƃ̑��Έʒu
	float2 SpTex			: TEXCOORD4;	// �X�t�B�A�}�b�v�e�N�X�`�����W
#ifdef MIKUMIKUMOVING
	float4 SS_UV1			: TEXCOORD5;	// �Z���t�V���h�E�e�N�X�`�����W
	float4 SS_UV2			: TEXCOORD6;	// �Z���t�V���h�E�e�N�X�`�����W
	float4 SS_UV3			: TEXCOORD7;	// �Z���t�V���h�E�e�N�X�`�����W
#endif
	float4 ScreenTex		: TEXCOORD8;
#ifdef USE_HGSHADOW
	float4 PPos				: TEXCOORD9;
#endif
	float4 Color			: COLOR0;		// �f�B�t���[�Y�F
};

#ifdef MIKUMIKUMOVING
VS_OUTPUT Basic_VS(MMM_SKINNING_INPUT IN, uniform bool useSelfShadow, uniform bool isEdge)
{
	MMM_SKINNING_OUTPUT SkinOut = MMM_SkinnedPositionNormal(IN.Pos, IN.Normal, IN.BlendWeight, IN.BlendIndices, IN.SdefC, IN.SdefR0, IN.SdefR1);
	float4 Pos = SkinOut.Position;
	float3 Normal = SkinOut.Normal;
	float2 Tex = IN.Tex;
#else
VS_OUTPUT Basic_VS(float4 Pos : POSITION, float3 Normal : NORMAL, float2 Tex : TEXCOORD0, uniform bool useSelfShadow, uniform bool isEdge)
{
#endif
	VS_OUTPUT Out = (VS_OUTPUT)0;

	Out.Eye.xyz = CameraPosition - mul(Pos, WorldMatrix);

	float dist = length(Out.Eye.xyz);

	if (isEdge)
	{
		float EdgeWeight = 0.001;

		if (!use_toon)
		{
			EdgeWeight *= 0.1;
			EdgeWidth = 1;
		}

#ifdef MIKUMIKUMOVING
		if (use_toon)
			EdgeWeight = IN.EdgeWeight;
#endif

#ifdef MIKUMIKUMOVING
		if (MMM_IsDinamicProjection)
			EdgeWeight *= MMM_GetDynamicFovEdgeRate(dist);
#endif

		Pos += float4(Normal, 0) * EdgeWeight * EdgeWidth * EdgeWidthRate * dist;
	}

#ifdef MIKUMIKUMOVING
	Out.Pos = mul(Pos, MMM_IsDinamicProjection ? mul(mul(WorldMatrix, ViewMatrix), MMM_DynamicFov(ProjMatrix, dist)) : WorldViewProjMatrix);
#else
	Out.Pos = mul(Pos, WorldViewProjMatrix);
#endif

#ifdef USE_HGSHADOW
	Out.PPos = Out.Pos;
#endif

	Out.Normal = normalize(mul(Normal, (float3x3)WorldMatrix));

#ifdef USE_LOCALSHADOW
	LightDirection[0] = LocalShadow_GetLightDirection(LightDirection[0]);
#endif

	float3 color = 0;
	float3 ambient = 0;
	int count = 0;

	[unroll]
	for (int i = 0; i < MMM_LightCount; i++)
		if (LightEnables[i])
		{
			color += (float3(1, 1, 1) - color) * max(0, DiffuseColor[i] * dot(Out.Normal, -LightDirection[i]));
			ambient += AmbientColor[i];
			count++;
		}

	Out.Color.rgb = saturate(ambient / count + color);
	Out.Color.a = DiffuseColor[0].a;
	Out.Tex = Tex;

#ifdef MIKUMIKUMOVING
	if (!use_spheremap)
		Out.SpTex.xy = IN.AddUV1.xy;

	if (useSelfShadow)
	{
		float4 dpos = mul(Pos, WorldMatrix);

		Out.SS_UV1 = mul(dpos, LightWVPMatrices[0]);
		Out.SS_UV2 = mul(dpos, LightWVPMatrices[1]);
		Out.SS_UV3 = mul(dpos, LightWVPMatrices[2]);
		Out.SS_UV1.y = -Out.SS_UV1.y;
		Out.SS_UV2.y = -Out.SS_UV2.y;
		Out.SS_UV3.y = -Out.SS_UV3.y;
		Out.SS_UV1.z = length(LightPositions[0] - Pos) / LightZFars[0];
		Out.SS_UV2.z = length(LightPositions[1] - Pos) / LightZFars[1];
		Out.SS_UV3.z = length(LightPositions[2] - Pos) / LightZFars[2];
	}
#else
	Out.ZCalcTex = mul(Pos, LightWorldViewProjMatrix);
#endif

#ifdef USE_LOCALSHADOW
	if (LocalShadow_Valid)
		Out.ZCalcTex = mul(Pos, LocalShadow_LightWorldViewProjMatrix);
#endif

	Out.ScreenTex = Out.Pos;

#ifdef USE_EXCELLENTSHADOW
	Out.Pos.z -= max(0, (int)((CameraDistance1 - 6000) * 0.04));
#endif

	return Out;
}

float CalculateSelfShadowValue(VS_OUTPUT IN)
{
#ifdef USE_LOCALSHADOW
	if (LocalShadow_Valid && LightEnables[0])
	{
		float4 uv = IN.ZCalcTex / IN.ZCalcTex.w;
		float2 TransTexCoord = 0.5 + uv * float2(0.5, -0.5);

		if (any(saturate(TransTexCoord) - TransTexCoord))
			return 1;
		else
		{
			float comp = LocalShadow_GetSelfShadowRate(TransTexCoord, uv.z);
			LocalShadow_COLOR Out = LocalShadow_GetShadowDensity(float4(1, 1, 1, 1), float4(0, 0, 0, 0), use_toon, dot(IN.Normal, -LightDirection[0]));

			return lerp(Out.ShadowColor, Out.Color, comp).r;
		}
	}
	else
#endif
	{
#ifdef USE_HGSHADOW
		if (HgShadow_Valid && LightEnables[0])
		{
			float comp = HgShadow_GetSelfShadowRate(IN.PPos);
			HgShadow_COLOR Out = HgShadow_GetShadowDensity(float4(1, 1, 1, 1), float4(0, 0, 0, 0), use_toon, dot(IN.Normal, -LightDirection[0]));

			return lerp(Out.ShadowColor, Out.Color, comp).r;
		}
		else
#endif
		{
#ifdef USE_EXCELLENTSHADOW
			if (Exist_ExcellentShadow)
			{
				IN.ScreenTex.xyz /= IN.ScreenTex.w;

				float2 TransScreenTex = 0.5 + IN.ScreenTex * float2(0.5, -0.5) + ViewportOffset;
				float ShadowMapVal = tex2D(ScreenShadowMapProcessedSamp, TransScreenTex).r;
				float ShadowColor = 0;
				float SSAOMapVal = 0;
				float3 lightdir = LightDirection[0];

				if (Exist_ExShadowSSAO)
					SSAOMapVal = tex2D(ExShadowSSAOMapSamp, TransScreenTex).r;

				if (use_toon)
				{
					ShadowMapVal = min(saturate(dot(IN.Normal, -lightdir) * 3), ShadowMapVal);
					ShadowColor *= 1 - (1 - ShadowRate) * PMD_SHADOWPOWER;
				}
				else
					ShadowColor *= 1 - (1 - ShadowRate) * X_SHADOWPOWER;

				float Color = 1;
				float ShadowColor2 = max(0, ShadowColor - (Color - ShadowColor + 0.3) * SSAOMapVal * 0.2);

				Color = lerp(Color, ShadowColor, saturate(SSAOMapVal * 0.4));
				Color = lerp(ShadowColor2, Color, ShadowMapVal);

				return Color;
			}
			else
#endif
			{
#ifdef MIKUMIKUMOVING
				return MMM_GetSelfShadowToonColor(float4(0, 0, 0, 1), IN.Normal, IN.SS_UV1, IN.SS_UV2, IN.SS_UV3, false, use_toon).r;
#else
				float4 uv = IN.ZCalcTex / IN.ZCalcTex.w;
				float2 TransTexCoord = 0.5 + uv * float2(0.5, -0.5);
				float comp = saturate(dot(IN.Normal, -LightDirection[0]) * 16 + 0.5);

				if (any(saturate(TransTexCoord) - TransTexCoord))
					return 1;
				else
				{
					comp = max(uv.z - tex2D(DefSampler, TransTexCoord).r, 0.0f);

					if (parthf)
						comp *= SKII2 * TransTexCoord.y - 0.3f;
					else
						comp *= SKII1 - 0.3f;

					comp = 1 - saturate(comp);

					return comp;
				}
#endif
			}
		}
	}
}

float4 Basic_PS(VS_OUTPUT IN, uniform bool useSelfShadow, uniform bool isEdge) : COLOR0
{
	float4 Color = IN.Color;
	float4 texColor = 1;
	float3 multiplySphereColor = 1;
	float3 addSphereColor = 0;
	BlendParameters ps = (BlendParameters)0;

	Color.a = clamp(Color.a, 0, 1);

	// normalmap
#ifdef USE_NORMALMAP
	float4 NormalColor = tex2D(NormalMapSampler, IN.Tex * NormalMapResolution) * 2;

	NormalColor = NormalColor.rgba;
	NormalColor.a = 1;

	float3x3 tangentFrame = ComputeTangentFrame(normalize(IN.Normal), normalize(IN.Eye), IN.Tex);

	IN.Normal = normalize(mul(NormalColor - 1.0, tangentFrame));
#endif

	ps.ViewNormal = NanAsZero(saturate(dot(IN.Normal, normalize(IN.Eye.xyz))));
	ps.ScreenCoordinate.xy = IN.ScreenTex.xy / IN.ScreenTex.w * 0.5 + float2(0.5, 0.5);
	ps.ScreenCoordinate.xy = float2(ps.ScreenCoordinate.x * ViewportSize.x / ViewportSize.y, 1 - ps.ScreenCoordinate.y) * ViewportSize.y;

	// texture
	if (use_texture)
	{
		texColor = tex2D(ObjTexSampler, IN.Tex);

		float texAlpha = MultiplyTexture.a + AddingTexture.a;

		texColor.rgb = (texColor.rgb * MultiplyTexture.rgb + AddingTexture.rgb) * texAlpha + (1.0 - texAlpha);
		Color *= texColor;
	}
	
///////////////////////////////
//PAToon�p�̏�������

	// spheremap
	if (use_spheremap)
	{
		//float2 SpTex = mul(IN.Normal, (float3x3)ViewMatrix).xy * float2(0.5, -0.5) + float2(0.5, 0.5);
        float2 SpTex = lerp((mul(IN.Normal, (float3x3)ViewMatrix).xy * float2(0.5, -0.5) + float2(0.5, 0.5)) ,LocalNormalToDirSph(mul((float3x3)BoneMatrixB, IN.Normal )), 1-SphereZ);


		
		if (spadd)
			addSphereColor = tex2D(ObjSphereSampler, SpTex).rgb * MultiplySphere.rgb + AddingSphere.rgb - AddingSphereP;
		else
		{
			multiplySphereColor = tex2D(ObjSphereSampler, SpTex).rgb * MultiplySphere.rgb + (( float3(1, 1, 1) -  tex2D(ObjSphereSampler, SpTex).rgb ) * (1 - MultiplySphereP)) + AddingSphere.rgb;
			Color.rgb *= multiplySphereColor;
		}



	}

    IN.Normal = normalize(mul(IN.Normal, (float3x3)BoneMatrixA ));

////////////////////////////////


	// shadow
	float shadowValue = 1;

#ifdef SHADE_TOONLESS
	use_toon = true;
#else
	#ifdef MIKUMIKUMOVING
	use_toon = use_toon ? usetoontexturemap : true;
	#else
	use_toon = use_toon ? MaterialToon != float3(1, 1, 1) : true;
	#endif
#endif

	// blending
	float3 diffuse = 0;
	float3 specular = 0;
	int lightCount = 0;

#ifdef USE_LOCALSHADOW
	LightDirection[0] = LocalShadow_GetLightDirection(LightDirection[0]);
#endif

	if (useSelfShadow)
	{
		shadowValue = CalculateSelfShadowValue(IN);

		if (transp) Color.a = 0.5f;
	}

	[unroll]
	for (int i = 0; i < MMM_LightCount; i++)
		if (LightEnables[i])
		{
			ps.LightNormal = NanAsZero(use_toon ? saturate(min(shadowValue, dot(IN.Normal, -LightDirection[i]))) : 1);
			ps.ExtendedLightNormal = NanAsZero(use_toon ? saturate(min(shadowValue, dot(IN.Normal, -LightDirection[i]) * 0.5 + 0.5)) : 1);
			ps.HalfVectorNormal = NanAsZero(saturate(dot(normalize(normalize(IN.Eye.xyz) + -LightDirection[i]), IN.Normal)));
			ps.SpecularValue = NanAsZero(saturate(pow(ps.HalfVectorNormal, SpecularPower)));
			ps.ToonValue = tex2D(ObjToonSampler, float2(0, 1 - ps.LightNormal)).rgb;

			if (isEdge)
				diffuse += BlendEdge(Color.rgb, ps);
			else
			{
#ifdef AMBIENT_AS_BASE
				float3 amb = AmbientColor[i] * texColor.rgb * multiplySphereColor;

	#ifdef AMBIENT_TOON_AS_BASE
				amb *= MaterialToon;
	#endif

				diffuse += amb + (BlendDiffuse(Color.rgb, ps) - amb) * (1 - amb);
#else
				diffuse += BlendDiffuse(Color.rgb, ps);
#endif
				specular += BlendSpecular(SpecularColor[i], ps);
				specular += BlendAddSphere(addSphereColor, ps);
			}

			lightCount++;
		}

	Color.rgb = saturate((diffuse + specular) / lightCount);

	return Color;
}

#ifdef HANDLE_EDGE

#define DRAW_EDGE_PASS(useSelfShadow) \
	pass DrawEdge \
	{ \
		CullMode = CW; \
		AlphaTestEnable = true; \
		VertexShader = compile vs_3_0 Basic_VS(useSelfShadow, true); \
		PixelShader  = compile ps_3_0 Basic_PS(useSelfShadow, true); \
	}

technique EdgeTec < string MMDPass = "edge"; >
{
}

#else

#define DRAW_EDGE_PASS(useSelfShadow)

///////////////////////////////////////////////////////////////////////
//PAToon�p�̒ǉ��i�m�[�}���G�b�W�j
// ���_�V�F�[�_
float4 ColorRender_VS(float4 Pos : POSITION) : POSITION 
{
    // �J�������_�̃��[���h�r���[�ˉe�ϊ�
    return mul( Pos, WorldViewProjMatrix );
}

// �s�N�Z���V�F�[�_
float4 ColorRender_PS() : COLOR
{
    // �֊s�F�œh��Ԃ�
    return EdgeColor;
}

// �֊s�`��p�e�N�j�b�N
technique EdgeTec < string MMDPass = "edge"; > {
    pass DrawEdge {
        AlphaBlendEnable = FALSE;
        AlphaTestEnable  = FALSE;

        VertexShader = compile vs_2_0 ColorRender_VS();
        PixelShader  = compile ps_2_0 ColorRender_PS();
    }
}
///////////////////////////////////////////////////////////////////////

#endif

#define DRAW_OBJECT_PASS(useSelfShadow) \
	pass DrawObject \
	{ \
		AlphaTestEnable = true; \
		VertexShader = compile vs_3_0 Basic_VS(useSelfShadow, false); \
		PixelShader  = compile ps_3_0 Basic_PS(useSelfShadow, false); \
	}

technique MainTec0 < string MMDPass = "object"; >
{
	DRAW_OBJECT_PASS(false)
		DRAW_EDGE_PASS(false)
}

technique MainTec1 < string MMDPass = "object_ss"; >
{
	DRAW_OBJECT_PASS(true)
		DRAW_EDGE_PASS(true)
}

///////////////////////////////////////////////////////////////////////////////////////////////
//HACore rel. 13 �����܂Ł@��
///////////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////////////////////
//PAToon�p�̒n�ʉe�ǉ��ݒ�

//------------------------------------------------------------------------------------------------//
// �n�ʉe�̕`��

float3 PlanarPos = float3(0.0, 0.1, 0.0);    // ���e���镽�ʏ�̔C�ӂ̍��W
float3 PlanarNormal = float3(0.0, 1.0, 0.0);  // ���e���镽�ʂ̖@���x�N�g��


float4x4 ViewProjMatrix  : VIEWPROJECTION;
float3   LightDirectionMMD  : DIRECTION < string Object = "Light"; >;

float3 LightDirectionCTR : CONTROLOBJECT < string name = PATOONCONTROLLER; string item = "�n�ʉe XYZ"; >;
float3 LightDirectionModel : CONTROLOBJECT < string name = "(self)"; string item = "�n�ʉe XYZ"; >;


static float3 LightDirectionBone = LightDirectionModel + LightDirectionCTR;

//static float3   LightDirection = DirectionP;

static float3 LightDirectionG = LightDirectionMMD + LightDirectionBone;



// ���_�V�F�[�_
float4 Shadow_VS(float4 Pos : POSITION) : POSITION
{
    // �����̉��ʒu(���s�����Ȃ̂�)
    float3 LightPos = Pos.xyz + LightDirectionG;

    // �C�ӕ��ʂɓ��e
    float a = dot(PlanarNormal, PlanarPos - LightPos);
    float b = dot(PlanarNormal, Pos.xyz - PlanarPos);
    float c = dot(PlanarNormal, Pos.xyz - LightPos);
    Pos = float4(Pos.xyz * a + LightPos * b, c);

    //Pos = float4(Pos.xyz * a + LightPos * b, c);

    // �r���[�ˉe�ϊ�
    return mul( Pos, ViewProjMatrix );
}

// �s�N�Z���V�F�[�_
float4 Shadow_PS() : COLOR
{
    // �n�ʉe�F�œh��Ԃ�
    return GroundShadowColor;
}

// �e�`��p�e�N�j�b�N
technique ShadowTec < string MMDPass = "shadow"; > {
    pass DrawShadow {
        VertexShader = compile vs_2_0 Shadow_VS();
        PixelShader  = compile ps_2_0 Shadow_PS();
    }
}
